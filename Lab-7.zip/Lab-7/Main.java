import java.util.*;

public class Main {
  public static void main(String[] args) {

    // 1. Vertices
    List<String> vertices = Arrays.asList(
        "Liberal Arts",                // 0
        "Student Services",            // 1
        "Health Careers & Sciences",   // 2
        "Health Technologies Center",  // 3
        "Recreation Center",           // 4
        "Technology Learning Center",  // 5
        "Business & Technology",       // 6
        "Theatre"                      // 7
    );

    // 2. Edges 
    List<Edge> edges = Arrays.asList(
        new Edge(0, 1), new Edge(1, 0),

        new Edge(1, 2), new Edge(2, 1),
        new Edge(1, 5), new Edge(5, 1),
        new Edge(1, 7), new Edge(7, 1),

        new Edge(2, 3), new Edge(3, 2),
        new Edge(2, 4), new Edge(4, 2),

        new Edge(4, 5), new Edge(5, 4),

        new Edge(5, 6), new Edge(6, 5),

        new Edge(6, 7), new Edge(7, 6)
    );

    // 3. Create graph
    UnweightedGraph<String> graph =
        new UnweightedGraph<>(vertices, edges);

    // 4. DFS from Business & Technology (vertex 6)
    UnweightedGraph<String>.SearchTree dfs = graph.dfs(6);

    // 5. DFS order
    System.out.println("DFS Search Order:");
    for (int i : dfs.getSearchOrder()) {
      System.out.print(vertices.get(i) + " -> ");
    }
    System.out.println();

    // 6. Parent-child relationships
    System.out.println("\nParent-Child Relationships:");
    for (int i = 0; i < vertices.size(); i++) {
      int parent = dfs.getParent(i);
      if (parent != -1) {
        System.out.println(
            vertices.get(parent) + " -> " + vertices.get(i)
        );
      }
    }

    // 7. Paths
    System.out.println("\nPaths:");

    dfs.printPath(3);
    System.out.println();

    dfs.printPath(1);
    System.out.println();

    dfs.printPath(4);
    System.out.println();

    // 8. Tree
    System.out.println("\nDFS Tree:");
    dfs.printTree();
  }
}