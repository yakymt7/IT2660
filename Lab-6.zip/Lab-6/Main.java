public class Main {
    public static void main(String[] args) {

        // Step 3 create map
        MyMap<String, Integer> creditHours = new MyHashMap<>();

        // Step 4 put values
        creditHours.put("IT-1025", 3);
        creditHours.put("IT-1050", 3);
        creditHours.put("IT-1150", 3);
        creditHours.put("IT-2310", 3);
        creditHours.put("IT-2320", 4);
        creditHours.put("IT-2351", 4);
        creditHours.put("IT-2650", 4);
        creditHours.put("IT-2660", 4);
        creditHours.put("IT-2030", 4);

        // Step 5 check keys
        System.out.println("Has IT-1025: " + (creditHours.get("IT-1025") != null));
        System.out.println("Has IT-2110: " + (creditHours.get("IT-2110") != null));

        // Step 6 print all key and value
        System.out.println("\n--- Full Map ---");
        String[] keys = {
                "IT-1025","IT-1050","IT-1150","IT-2310",
                "IT-2320","IT-2351","IT-2650","IT-2660","IT-2030"
        };

        for (String key : keys) {
            Integer value = creditHours.get(key);
            if (value != null) {
                System.out.println(key + " -> " + value);
            }
        }

        // Step 7 remove
        creditHours.remove("IT-2030");
        creditHours.remove("IT-1150");

        // Step 8 print only values
        System.out.println("\n--- Values Only ---");
        for (String key : keys) {
            Integer value = creditHours.get(key);
            if (value != null) {
                System.out.println(value);
            }
        }
    }
}