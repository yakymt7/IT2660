public class Main {
    public static void main(String[] args) {

        // Create BST
        BST<Integer> lab5Tree = new BST<>();

        // Insert values
        int[] values = {13, 22, 36, 5, 48, 17, 39, 2, 26, 40, 29, 34, 10};
        for (int v : values) {
            lab5Tree.insert(v);
        }

        // Delete 17
        lab5Tree.delete(17);

        
        System.out.println("Inorder (sorted):");
        lab5Tree.inorder();

        
        System.out.println("\nPostorder:");
        lab5Tree.postorder();

        
        System.out.println("\nPreorder:");
        lab5Tree.preorder();

        // Search
        System.out.println("\nSearch 36: " + lab5Tree.search(36));
        System.out.println("Search 37: " + lab5Tree.search(37));

        
        System.out.println("\n\nPath to 2:");
        for (BST.TreeNode<Integer> node : lab5Tree.path(2)) {
            System.out.print(node.element + " ");
        }

        
        System.out.println("\n\nPath to 34:");
        for (BST.TreeNode<Integer> node : lab5Tree.path(34)) {
            System.out.print(node.element + " ");
        }

        System.out.println(); // final newline
    }
}